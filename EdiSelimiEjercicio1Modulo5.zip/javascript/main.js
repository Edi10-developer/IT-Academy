// Funcion de calculo
function muestraResultado() {
  let numero1 = parseInt(prompt("Primer numero:"));
  let operador = prompt("Operdaor:");
  let numero2 = parseInt(prompt("Secundo numero:"));
  let div = document.getElementById("datos");
  let resultado;

  switch (operador) {
    case "+":
      resultado = suma(numero1, numero2);
      break;
    case "-":
      resultado = resta(numero1, numero2);
      break;
    case "*":
      resultado = multiplica(numero1, numero2);
      break;
    case "/":
      resultado = divide(numero1, numero2);
      break;
    case "%":
      resultado = divideConResto(numero1, numero2);
      break;
    default:
      alert("Los datos introducidos no son correctos");
  }

  div.innerHTML =
    resultado + `<button onClick="reload();" id="close">X</button>`;
}

// Funcion Sumar
function suma(numero1, numero2) {
  resultado = numero1 + numero2;
  return resultado;
}

// Funcion Restar
function resta(numero1, numero2) {
  resultado = numero1 - numero2;
  return resultado;
}

// Funcion Multiplicar
function multiplica(numero1, numero2) {
  resultado = numero1 * numero2;
  return resultado;
}

// Funcion Dividir
function divide(numero1, numero2) {
  resultado = numero1 / numero2;
  return resultado;
}

// Funcion Modular
function divideConResto(numero1, numero2) {
  resultado = numero1 % numero2;
  return resultado;
}

// Refresh page
function reload() {
  location.reload();
}
