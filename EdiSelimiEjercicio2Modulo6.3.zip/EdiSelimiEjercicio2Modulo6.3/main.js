// Funccion principal
function reverseString() {
  let stringInserida = document.getElementById("string").value;
  let result = document.getElementById("resultado");
  let stringReverse = "";

  let string = new Array();
  let i;

  string.push(stringInserida);

  for (i = stringInserida.length - 1; i >= 0; i--) {
    stringReverse += stringInserida[i];
  }
  
  result.style.display = "block";
  result.innerHTML = stringReverse;
}
