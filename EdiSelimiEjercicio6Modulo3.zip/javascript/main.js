const datos = document.getElementById("datos");

function muestraResultado() {
  let day = parseInt(prompt("Que dia del mes naciste?"));
  let mes = parseInt(prompt("Que mes naciste? en numero"));
  let zodiacSimbol;

  if ((day <= 19 && mes == 1) || (day >= 22 && mes == 12)) {
    zodiacSimbol = "Capricorn";
  } else if ((day > 19 && mes == 1) || (day <= 19 && mes == 2)) {
    zodiacSimbol = "Aquarium";
  } else if ((day >= 20 && mes == 2) || (day <= 20 && mes == 3)) {
    zodiacSimbol = "Pez";
  } else if ((day > 20 && mes == 3) || (day <= 20 && mes == 4)) {
    zodiacSimbol = "Aries";
  } else if ((day > 21 && mes == 4) || (day <= 20 && mes == 5)) {
    zodiacSimbol = "Taurus";
  } else if ((day > 20 && mes == 5) || (day <= 21 && mes == 6)) {
    zodiacSimbol = "Gemini";
  } else if ((day > 21 && mes == 6) || (day <= 22 && mes == 7)) {
    zodiacSimbol = "Cancer";
  } else if ((day > 22 && mes == 7) || (day <= 22 && mes == 8)) {
    zodiacSimbol = "Leo";
  } else if ((day > 22 && mes == 8) || (day <= 23 && mes == 9)) {
    zodiacSimbol = "Virgo";
  } else if ((day > 23 && mes == 9) || (day <= 22 && mes == 10)) {
    zodiacSimbol = "Libra";
  } else if ((day > 22 && mes == 10) || (day <= 22 && mes == 11)) {
    zodiacSimbol = "Escorpio";
  } else if ((day > 22 && mes == 11) || (day <= 21 && mes == 12)) {
    zodiacSimbol = "Sagittarius";
  } else {
    alert("Volver a poner las fechas!");
  }

  datos.style.opacity = 1;
  datos.innerHTML =
    "Por las fecha en que naciste, tu signo zodiacal es " + zodiacSimbol;
}
