let randomNum = Math.ceil(Math.random() * 10);

tentativos = 0;

function loteria() {
  let trueNumb;
  while (randomNum != trueNumb) {
    trueNumb = parseInt(prompt("Qual crees se el numero ganador?"));
    tentativos++;
  }
  alert(
    "Enhorabuena! has adovinado el numero " +
      randomNum +
      " en " +
      tentativos +
      " tentativos "
  );
}
