const datos = document.getElementById('datos');

function muestraDatos() {
    var nombre = prompt("Nombre: ",);
    var apellido = prompt("Apellido :",);
    var edad = prompt("Eda: ",);

    const datosPuestos = "Edad: " + nombre + " " + "Apellidos: " + apellido + " " + "Edad : " + edad;

    datos.style.opacity = '1';

    // Por pantalla (aunque no pedido)
    datos.innerHTML = datosPuestos;

    // Por consola
    console.log(datosPuestos);

    // Por popup
    alert(datosPuestos)
}

