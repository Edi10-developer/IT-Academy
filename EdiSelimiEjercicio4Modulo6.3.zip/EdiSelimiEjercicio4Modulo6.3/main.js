// Funcion principal
function start() {
  let phrase = document.getElementById("frase").value.replace(/ /g, '');  //replace(/ /g, ''); quita los espacios de la string en manera global
  let result = document.getElementById('result');
  let reversePhrase = "";
  
  let i;

  for (i = phrase.length; i > 0; i--) {
    reversePhrase += phrase[i-1];
  }
 
  let msg = isPalindroma(phrase, reversePhrase);

  result.style.display = 'block';
  result.innerHTML = msg;
}

// Funcion para sacar el resultado
function isPalindroma(phrase, reversePhrase){
  if(phrase === reversePhrase && phrase != ''){
    msg = "Es una frase PALINDROMA";
  }else if(phrase !== reversePhrase){
     msg = "NO es una frase PALINDROMA";
  }else{
    msg = "Los datos introducidos son INCORRECTOS!";
  }
  return msg;
}