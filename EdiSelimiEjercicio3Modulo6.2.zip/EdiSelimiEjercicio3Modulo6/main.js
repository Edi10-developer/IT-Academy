// Funcion para calcular el resultado del problema
function calcula() {
  let randomNumero = Math.ceil(Math.random() * 100);
  let numeroInserido = parseInt(document.getElementById("numero").value);
  let resultDiv = document.getElementById("resultDiv");
  let mensaje;

  if (numeroInserido > randomNumero) {
    mensaje = "El umero " + numeroInserido + " es demasiado alto";
  } else if (numeroInserido < randomNumero) {
    mensaje = "El umero " + numeroInserido + " es demasiado bajo";
  } else if (numeroInserido === randomNumero) {
    mensaje = "Has acertado! El umero " + numeroInserido + " es correcto";
  }

  resultDiv.innerHTML = mensaje;
}
