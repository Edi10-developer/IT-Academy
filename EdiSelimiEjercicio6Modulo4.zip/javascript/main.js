const datos = document.getElementById("datos");

function muestraResultado() {
  let day = parseInt(prompt("Que dia del mes naciste?"));
  let mes = parseInt(prompt("Que mes naciste? en numero"));
  let zodiacSimbol;

  switch (mes) {
    case 1:
      if (day <= 19) {
        zodiacSimbol = "Capricorn";
      } else {
        zodiacSimbol = "Aquarium";
      }
      break;
    case 2:
      if (day <= 19) {
        zodiacSimbol = "Aquarium";
      } else {
        zodiacSimbol = "Piscis";
      }
      break;
    case 3:
      if (day <= 20) {
        zodiacSimbol = "Piscis";
      } else {
        zodiacSimbol = "Aries";
      }
      break;
    case 4:
      if (day <= 20) {
        zodiacSimbol = "Aries";
      } else {
        zodiacSimbol = "Taurus";
      }
      break;
    case 5:
      if (day <= 20) {
        zodiacSimbol = "Taurus";
      } else {
        zodiacSimbol = "Gemini";
      }
      break;
    case 6:
      if (day <= 21) {
        zodiacSimbol = "Gemini";
      } else {
        zodiacSimbol = "Cancer";
      }
      break;
    case 7:
      if (day <= 22) {
        zodiacSimbol = "Cancer";
      } else {
        zodiacSimbol = "Leo";
      }
      break;
    case 8:
      if (day <= 22) {
        zodiacSimbol = "Leo";
      } else {
        zodiacSimbol = "Virgo";
      }
      break;
    case 9:
      if (day <= 23) {
        zodiacSimbol = "Virgo";
      } else {
        zodiacSimbol = "Libra";
      }
      break;
    case 10:
      if ((day > 23 && mes == 9) || (day <= 22 && mes == 10)) {
        zodiacSimbol = "Libra";
      }
      break;
    case 11:
      if (day <= 22) {
        zodiacSimbol = "Escorpio";
      } else {
        zodiacSimbol = "Sagittarius";
      }
      break;
    case 12:
      if (day <= 21) {
        zodiacSimbol = "Sagittarius";
      } else {
        zodiacSimbol = "Capricorn";
      }
      break;
  }

  datos.style.opacity = 1;
  datos.innerHTML =
    "Por las fecha en que naciste, tu signo zodiacal es " + zodiacSimbol;
}

/*
  if ((day <= 19 && mes == 1) || (day >= 22 && mes == 12)) {
    zodiacSimbol = "Capricorn";
  } else if ((day > 19 && mes == 1) || (day <= 19 && mes == 2)) {
    zodiacSimbol = "Aquarium";
  } else if ((day >= 20 && mes == 2) || (day <= 20 && mes == 3)) {
    zodiacSimbol = "Piscis";
  } else if ((day > 20 && mes == 3) || (day <= 20 && mes == 4)) {
    zodiacSimbol = "Aries";
  } else if ((day > 21 && mes == 4) || (day <= 20 && mes == 5)) {
    zodiacSimbol = "Taurus";
  } else if ((day > 20 && mes == 5) || (day <= 21 && mes == 6)) {
    zodiacSimbol = "Gemini";
  } else if ((day > 21 && mes == 6) || (day <= 22 && mes == 7)) {
    zodiacSimbol = "Cancer";
  } else if ((day > 22 && mes == 7) || (day <= 22 && mes == 8)) {
    zodiacSimbol = "Leo";
  } else if ((day > 22 && mes == 8) || (day <= 23 && mes == 9)) {
    zodiacSimbol = "Virgo";
  } else if ((day > 23 && mes == 9) || (day <= 22 && mes == 10)) {
    zodiacSimbol = "Libra";
  } else if ((day > 22 && mes == 10) || (day <= 22 && mes == 11)) {
    zodiacSimbol = "Escorpio";
  } else if ((day > 22 && mes == 11) || (day <= 21 && mes == 12)) {
    zodiacSimbol = "Sagittarius";
  } else {
    alert("Volver a poner las fechas!");
  }
*/
