const datos = document.getElementById("datos");

function muestraResultado() {
  let number = parseInt(document.getElementById("number").value);

  let alumno = [];
  let text = "";
  let i;

  for (i = 0; i < number; i++) {
    let nombreAlumno = prompt("Nombre del alumno:");
    let edadAlumno = parseInt(prompt("Edad alumno: "));
    let tituloUniversitario = prompt("Tiene titulo universitario? ");
    let paroAlumno = prompt("Tiene paro? ");

    tituloUniversitario = tituloUniversitario.toLocaleLowerCase();
    paroAlumno = paroAlumno.toLocaleLowerCase();

    if (
      (edadAlumno >= 18 && tituloUniversitario == "si") ||
      paroAlumno == "si"
    ) {
      alumno.push(nombreAlumno);
      text += nombreAlumno + "<br/>";
    }
  }
  datos.innerHTML = text;
}
