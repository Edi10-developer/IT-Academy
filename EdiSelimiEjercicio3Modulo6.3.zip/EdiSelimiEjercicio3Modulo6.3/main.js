// Funcion principal
function start() {
  let resultDiv = document.getElementById('result');
  const numbers = prompt("Cuantos numeros quieres escribir?");
  let numbersContainer = [];
  let i, number;

  for (i = 0; i < numbers; i++) {
    number = prompt("Escribe un numero: ");
    numbersContainer.push(number);
  }

  progressive(numbersContainer);
  
  resultDiv.style.display = 'block';
  resultDiv.innerHTML = numbersContainer;
}

// Funcion para ordenar los numeros en orden progresivo
function progressive(numbersContainer) {
  let i, j;

  for (i = 0; i < numbersContainer.length; i++) {
    for (j = 0; j < numbersContainer.length; j++) {
      if (numbersContainer[j] > numbersContainer[j + 1]) {
        let progressiveNumber = numbersContainer[j];
        numbersContainer[j] = numbersContainer[j + 1];
        numbersContainer[j + 1] = progressiveNumber;
      }
    }
  }

  return numbersContainer;
}
