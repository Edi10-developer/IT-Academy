// Funcion para sacar medio arbol de Navidad
function calcula() {
  let resultDiv = document.getElementById("resultDiv");
  let numero = parseInt(document.getElementById("numero").value);
  let arbol = "";
  let asterisco = "*";
  let arbolDecr = "";

  let i, j;

  for (i = 1; i <= numero; i++) {
    for (let j = 1; j <= i; j++) {
      arbol += asterisco;
    }
    arbol += "<br/>";
  }
  
  for (i = numero; i >= 1; i--) {
      for (j = 2; j <= i; j++) {
        arbolDecr += asterisco;
      }
      arbolDecr += "<br/>";
    }

resultDiv.innerHTML = arbol + arbolDecr;
}

