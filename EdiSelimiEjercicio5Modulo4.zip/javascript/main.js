const datos = document.getElementById("datos");

function muestraResultado() {
  let number = parseInt(document.getElementById("number").value);

  let alumno = [];
  let text = "";
  let nombreAlumno, edadAlumno, tituloUniversitario, paroAlumno;

  do {
    nombreAlumno = prompt("Nombre del alumno:");
    edadAlumno = parseInt(prompt("Edad alumno: "));
    tituloUniversitario = prompt("Tiene titulo universitario? ");
    paroAlumno = prompt("Tiene paro? ");

    tituloUniversitario = tituloUniversitario.toLocaleLowerCase();
    paroAlumno = paroAlumno.toLocaleLowerCase();

    if (
      (edadAlumno >= 18 && tituloUniversitario == "si") ||
      paroAlumno == "si"
    ) {
      alumno.push(nombreAlumno);
      text += nombreAlumno + "<br/>";
    }
  } while (alumno.length < 5);

  datos.innerHTML = text;
}

/************************************** 
const datos = document.getElementById("datos");

function muestraResultado() {
  let number = parseInt(document.getElementById("number").value);

  let alumno = [];
  let text = "";
  let nombreAlumno, edadAlumno, tituloUniversitario, paroAlumno;
  let i;

  do {
    nombreAlumno = prompt("Nombre del alumno:");
    edadAlumno = parseInt(prompt("Edad alumno: "));
    tituloUniversitario = prompt("Tiene titulo universitario? ");
    paroAlumno = prompt("Tiene paro? ");
    tituloUniversitario = tituloUniversitario.toLocaleLowerCase();
    paroAlumno = paroAlumno.toLocaleLowerCase();

    alumno.push(nombreAlumno);
    text += nombreAlumno + "<br/>";
  } while (
    (edadAlumno >= 18 && tituloUniversitario == "si") ||
    (paroAlumno == "si" && alumno.length <= 5)
  );

  datos.innerHTML = text;
}
*/
