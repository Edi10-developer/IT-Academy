// Funcion para calcular el resultado del problema
function calcula() {
  let numero1 = parseInt(document.getElementById("numero1").value);
  let numero2 = parseInt(document.getElementById("numero2").value);
  let numero3 = parseInt(document.getElementById("numero3").value);
  let text = "";
  let resultDiv = document.getElementById("resultDiv");
  let media = mediaNotas(numero1, numero2, numero3);

  if((numero1 > 10) || (numero2 > 10) || (numero3 > 10)){
    text = "Los datos introducidos no son corrrectos";
    media = "";
  } else if(media < 5) {
    text = "No has superado el curso. Tienes que recuperar";
  } else if(media < 7) {
    text = "Enhorabuena! Has aprobado pero deberías seguir practicando";
  } else if(media <= 10) {
    text = "Enhorabuena! Has superado el curso! Pasa ya al siguiente nivel!"
  }
  resultDiv.innerHTML = media += '<br/>' + text;;
}

// Funcion para calcular la media de las notas
function mediaNotas(numero1, numero2, numero3){
  media = ((numero1 + numero2 + numero3) / 3);
  return media;
}

