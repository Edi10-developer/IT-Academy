let resultDiv = document.getElementById("resultDiv");
let mediaNotas, nota1, nota2;

// Funcion principal
function calcula() {
  mediaNotas = calculaMediaNotas();
  resultDiv.innerHTML = "<h5>" + mediaNotas + "</h5>";
}

function calculaMediaNotas(nota1, nota2, mediaNotas) {
  nota1 = parseInt(document.getElementById("nota1").value);
  nota2 = parseInt(document.getElementById("nota2").value);
  mediaNotas = (nota1 + nota2) / 2;
  return mediaNotas;
}
