// Funcion sumar numeros par y inpar in diferentes Arrays
function calcula() {
  let numero1 = parseInt(document.getElementById("numero1").value);
  let numero2 = parseInt(document.getElementById("numero2").value);
  let reaultDiv = document.getElementById("resultDiv");

  let result = negativos(numero1, numero2);
  resultDiv.innerHTML = result;
}

function negativos(numero1, numero2) {
  if ((numero1 < 0 && numero2 > 0) || (numero1 > 0 && numero2 < 0)) {
    result = "Uno de los dos numero es negativo";
  } else if (numero1 < 0 && numero2 < 0) {
    result = "Los dos numeros son negativos";
  } else if (numero1 > 0 && numero2 > 0) {
    result = "Los dos numeros son positivos";
  } else {
    result = "Los numeros no han sido inseridos correctamente";
  }
  return result;
}


/******************************************************************************
                      SECUNDO TENTATICO FUNCTION NEGATIVOS()
- no entiendo porque no me recoje los valores del Switch y va al default
*******************************************************************************/
/*
function negativos(numero1, numero2) {
let zero = 0;
  switch (zero) {
    case zero > numero1:
    case zero > numero2:
      result = "Uno de los dos numero es negativo";
      break;
    case zero > numero1 && zero > numero2:
      result = "Los dos numeros son negativos";
      break;
    case zero < numero1 && zero < numero2: 
      result = "Los dos numeros son positivos";
      break;
    default:
      result = "Los numeros no han sido introducidos correctamente";
  }
  return result;
}
*/
