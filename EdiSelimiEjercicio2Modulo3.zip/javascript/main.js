const datos = document.getElementById('datos');

function muestraResultado() {
    let edadUsuario = parseInt(prompt("Cuanto años tienes?"));
    let mensaje;
   
    if(edadUsuario <= 5){
        mensaje = "Preescolar";
    } else if (edadUsuario >= 6 && edadUsuario <= 11){
        mensaje = "Primaria";
    } else if( edadUsuario >= 12 && edadUsuario <= 15){
        mensaje = "ESO";
    } else if (edadUsuario >= 16 && edadUsuario <= 18){
        mensaje = "Bachillerato";
    } else{
        mensaje = " FP o Universidad";
    }
    datos.innerHTML = "Tienes una edad para ir a la " + mensaje;
    datos.style.opacity = 1;
}



