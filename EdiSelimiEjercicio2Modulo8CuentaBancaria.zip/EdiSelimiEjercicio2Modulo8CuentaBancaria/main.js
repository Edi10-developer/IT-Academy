var cuentas = [];
let cuenta1 = new Cuenta("Mario", "Lopez", 0101);
cuentas.push(cuenta1);

const resultado = document.getElementById("resultado");

// Dar de alta cliente
function altaCliente() {
  let nombre = prompt("Cual es su nombre:");
  let apellido = prompt("Su apellido: ");
  // let titular = nombre + ' ' + apellido;
  let numeroCuenta = parseInt(
    prompt("Por favor introduzca un numero de cuenta: ")
  );
  let encontrada = false;
  var cuen;

  for (cuen of cuentas) {
    if (
      cuen.getNombre() == nombre &&
      cuen.getApellido() == apellido &&
      cuen.getNumeroCuenta() == numeroCuenta
    ) {
      encontrada = true;
    } else {
      cuen++;
    }
  }
  if (!encontrada) {
    let cuentaCliente = new Cuenta(nombre, apellido, numeroCuenta);
     cuentas.push(cuentaCliente);
    swal({
      title: "Congratulaciones",
      text: "La cuenta ha sido creada correctamente.",
      icon: "success",
    });
  } else {
    swal({
      title: "Lo sentimos! \n La cuenta  ya existe en el sistema.",
      text: cuen.toString(),
      icon: "error",
    });
  }
}

// Eliminar Cuenta
function eliminarCuenta() {
  let nombre = prompt("Cual es el nombre de la cuenta que desea borrar:");
  let apellido = prompt("El apellido: ");
  let numeroCuenta = parseInt(
    prompt("Por favor introduzca un numero de cuenta que desea borrar: ")
  );
  let encontrada = false;
  var cuen;

  for (cuen of cuentas) {
    if (
      cuen.getNombre() == nombre &&
      cuen.getApellido() == apellido &&
      cuen.getNumeroCuenta() == numeroCuenta
    ) {
      encontrada = true;
    } else {
      cuen++;
    }
  }
  if (!encontrada) {
    swal({
      title: "Lo sentimos.",
      text: "La cuenta no existe en el sistema. ",
      icon: "error",
    });
  } else {
    cuentas.splice(cuentas.indexOf(cuentas.cuen), 1);
    swal({
      title: "Congratulaciones",
      text: "La cuenta ha sido eliminada correctamente.",
      icon: "success",
    });
  }
}

// Ver detalles de la cuenta
function verCuenta() {
  let nombre = prompt("Cual es el nombre de la cuenta que desea ver los detalles:"
  );
  let apellido = prompt("El apellido: ");
  let numeroCuenta = parseInt(
    prompt("Por favor introduzca un numero de cuenta que desea ver: ")
  );
  let encontrada = false;
  var cuen;

  for (cuen of cuentas) {
    if (
      cuen.getNombre() == nombre &&
      cuen.getApellido() == apellido &&
      cuen.getNumeroCuenta() == numeroCuenta
    ) {
      encontrada = true;
    } else {
      cuen++;
    }
  }
  if (encontrada) {
    resultado.innerHTML = cuen.toString();
  } else {
    swal({
      title: "Lo sentimos.",
      text: "La cuenta no existe en el sistema o ha sido eliminada. ",
      icon: "error",
    });
  }
}

// Realizar operaciones
function realizarOperaciones() {
  let nombre = prompt("El nombre de su cuenta: ");
  let apellido = prompt("Su apellido: ");
  let numeroCuenta = parseInt(
    prompt("Por favor introduzca su un numero de cuenta: ")
  );
  let encontrada = false;
  var cuen;

  for (cuen of cuentas) {
    if (
      cuen.getNombre() == nombre &&
      cuen.getApellido() == apellido &&
      cuen.getNumeroCuenta() == numeroCuenta
    ) {
      encontrada = true;
    } else if (
      cuen.getNombre() == nombre &&
      cuen.getApellido() == apellido &&
      cuen.getNumeroCuenta() != numeroCuenta
    ) {
      swal({
        title: "Lo sentimos, tenemos un numero de cuenta diferentes en su nombre.",
        text: cuen.toString(),
        icon: "error",
      });
    
    } else {
      cuen++;
    }
  }
  if (encontrada) {
    let operacion = parseInt(
      prompt("Que operacion desea realizar: \n 1.- Ingresar dinero,  \n 2.- Retitar dinero, \n 3.- Ver saldo total, \n 4.- Ver transacciones, \n 5.- Ver detalles cuenta"
      )
    );

    switch (operacion) {
      case 1:
        cuen.ingresar();
        break;
      case 2:
        cuen.retirar();
        break;
      case 3:
        resultado.innerHTML =
          "Su saldo actual es de " + cuen.getSaldo() + " euro.";
        break;
      case 4:
        resultado.innerHTML =
          "El numero de transacciones totales en su cuenta es " +
          cuen.getTransacciones() +
          ".";
        break;
      case 5:
        resultado.innerHTML = cuen.toString();
        break;
      default:
        swal({
          title: "Lo sentimos",
          text: 'Los datos introducidos son incorrectos',
          icon: "error",
        });
    }
  }
}
