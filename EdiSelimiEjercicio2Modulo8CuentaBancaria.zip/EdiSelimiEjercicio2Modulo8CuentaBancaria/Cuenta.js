class Cuenta{
    constructor(nombre, apellido, numeroCuenta, saldo, numeroTransaciones){
        this._nombre        = nombre;
        this._apellido      = apellido;
     // this._titular       = nombre + ' ' + apellido;
        this._numeroCuenta  = numeroCuenta;
        this._saldo         =  50;
        this._transacciones = 0;
    }

    // SET
    setNombre(nombre){
        this._nombre = nombre;
    }
    setApellido(apellido){
        this._apellido = apellido;
    }
    setSaldo(saldo){
        this._saldo = saldo;
    }
    setNumeroCuenta(numeroCuenta){
        this._numeroCuenta = numeroCuenta;
    }
    setTransacciones(transacciones){
        this._transacciones = transacciones;
    }

    // GET
    getNombre(){
        return this._nombre;
    }
    getApellido(){
        return this._apellido;
    }
    getSaldo(){
        return this._saldo;
    }
    getNumeroCuenta(){
        return this._numeroCuenta;
    }
    getTransacciones(){
        return this._transacciones;
    }

    // Medotos addiccionales
    toString(){
         let msg ='La cuenta numero ' + this._numeroCuenta + ' de ' + this._nombre + ' ' + this._apellido + ', tiene un saldo de ' + this._saldo + ' euro y ha realizado ' + this._transacciones + ' transacciones.'; 
         return msg;
    }

    ingresar(){
        let ingreso = parseInt(prompt('Dinero que desea ingresar:'));
        this._saldo = this._saldo + ingreso;
        swal({
            title: "Congratulaciones",
            text: "El dinero ha sido ingresado correctamente.",
            icon: "success",
          });

        this._transacciones = this._transacciones + 1; // Aumento el numero de transacciones
        return this._saldo;
    }
    retirar(){
        let sacado = parseInt(prompt('Dinero que desea retirar:'));
        if(sacado < this._saldo){
            this._saldo = this._saldo - sacado;
            swal({
                title: "Congratulaciones",
                text: "El dinero ha sido retirado correctamente.",
                icon: "success",
              });
    
            this._transacciones = this._transacciones + 1; // Aumento el numero de transacciones
        }else{
            swal({
                title: "Lo sentimos",
                text: "No hay saldo suficiente en la cuenta.",
                icon: "error",
              });
        } 
        return this._saldo;
    }
}
