// Funcion para calcular el resultado del problema
function calcula() {
  let numero = parseInt(prompt("Introduce un numero primo:"));
  let primo = true;
  let i = 2;

  while (primo && i < numero) {
    if (numero % i == 0) {
      primo = false;
    }
    i++;
  }
    switch (primo) {
      case true:
        alert(`Enhorabuena! El numero ${numero} es un numero PRIMO`);
        break;
      case false:
        alert(`Ententalo de nuevo! El numero ${numero} NO es un numero PRIMO`);
        break;
    }
  }

