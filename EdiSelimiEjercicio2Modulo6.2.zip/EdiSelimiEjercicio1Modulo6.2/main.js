// Funcion para calcular el resultado del problema
function calcula() {
  let resultDiv = document.getElementById("resultDiv");
  let avg = mediaNotas();
  let mensaje;

  if (avg < 5) {
    mensaje =
      "La nota media de la clase es de suspenso. Los alumnos deberían preguntar sus dudas y trabajar más por su cuenta";
  } else if (avg < 7) {
    mensaje =
      "La nota media de la clase es buena pero los alumnos deberían mejorar el trabajo personal";
  } else {
    mensaje =
      "Enhorabuena! La nota media de la clase se corresponde con el esfuerzo que habéis realizado";
  }
  resultDiv.innerHTML = "Media classe: " + avg + "<br/>" + mensaje;
}

// Funcion para calcular nota media
function mediaNotas() {
  let alumnos = parseInt(document.getElementById("numero").value);
  let sumaNotas = 0;
  let i, nota;

  for (i = 0; i < alumnos; i++) {
    nota = parseInt(prompt("Media alumno:"));
    if (nota <= 10 && nota >= 0) {
      sumaNotas = sumaNotas + nota;
    } else {
      alert("Ls nota introducida no es correcta!");
    }
  }
  avg = sumaNotas / alumnos;

  return avg;
}
