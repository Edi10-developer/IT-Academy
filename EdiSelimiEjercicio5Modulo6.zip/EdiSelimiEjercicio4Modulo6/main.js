function calcula() {
  let tabla = document.getElementById("tabla");
  let numero = parseInt(document.getElementById("numero").value);
  let numeros = [];
  let result;
  let text = "";
  let i;

  for (i = 1; i <= 10; i++) {
    numeros.push(numero);
    result = numero * i;
    text += "<p>" + numero + " X " + i + " = " + result + "</p>";
  }
  tabla.innerHTML = text;

  /* console.log(numero * i); */
}
