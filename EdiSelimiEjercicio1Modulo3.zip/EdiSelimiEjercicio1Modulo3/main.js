const datos = document.getElementById('datos');

function muestraResultado() {
    let numeroPuertasCoche = parseInt(prompt("Cuantas puertas desea que su coche tenga?"));
   
    if(numeroPuertasCoche == 3){
        alert("Su coche es deportivo!");
    } else if(numeroPuertasCoche === 5) {
        alert("Su coche es familiar!");
    } else {
        alert("Esta seguro del numero de las puertas de su coche?");
    }
    
}

