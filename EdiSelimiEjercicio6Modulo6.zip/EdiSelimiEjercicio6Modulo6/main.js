// Funcion para sacar medio arbol de Navidad
function calcula() {
  let numero = parseInt(document.getElementById("numero").value);
  let resultDiv = document.getElementById("resultDiv");
  let arbol = [];
  let ramos = [];
  let asterisco = "*";
  let i;

  for (i = 0; i < numero; i++) {
    ramos.push(asterisco);
    arbol.push(ramos + "<br/>");
  }
  resultDiv.innerHTML = arbol + `<br/><button onClick=arbolEntero();>Mirame Entero</button>`;
}

// Esta funcion permite de mirar el arbol entero
function arbolEntero(){
  resultDiv.style.textAlign = 'center';
}