const datos = document.getElementById("datos");

function muestraResultado() {
  let number1 = parseInt(prompt("Dime un numero"));
  let calc = prompt("Operador de calculo:");
  let number2 = parseInt(prompt("Dime otro numero"));

  let result;

  switch (calc) {
    case "+":
      result = number1 + number2;
      break;
    case "-":
      result = number1 - number2;
      break;
    case "*":
      result = number1 * number2;
      break;
    case "/":
      result = number1 / number2;
      break;
    default:
      result = "El operador de calculo inserido no es valido!";
  }

  datos.innerHTML =
    `<h3>Calculadora</h3><p>El resultado de la operacion: ` +
    number1 +
    " " +
    calc +
    " " +
    number2 +
    " es igual a " +
    result +
    `</p>`;
  datos.style.opacity = 1;
}
