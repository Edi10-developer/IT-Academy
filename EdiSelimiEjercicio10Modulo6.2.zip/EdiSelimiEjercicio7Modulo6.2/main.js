// Cuadrado
function calculaAreaCuadrado(){
  let altura = document.getElementById('alturaCuadrado').value;
  let base = document.getElementById('baseCuadrado').value;
  let result = document.getElementById('areaCuadrado');

  let area = base * altura;

  result.innerHTML ="La area es de " + area + " cm²";
}


// Triangulo
function calculaAreaTriangulo(){
  let altura = document.getElementById('alturaTriangulo').value;
  let base = document.getElementById('baseTriangulo').value;
  let result = document.getElementById('areaTriangulo');

  let area = base * altura / 2;

  result.innerHTML ="La area es de " + area + " cm²";
}



// Circulo
function calculaAreaCirculo(){
  let radio = document.getElementById('radioCirculo').value;
  let piGriego = 3.14;
  let result = document.getElementById('areaCirculo');

  let area = (radio * radio * piGriego);

  result.innerHTML ="La area es de " + area + " cm²";
}


// Rectangulo
function calculaAreaRectangulo(){
  let altura = document.getElementById('alturaRectangulo').value;
  let base = document.getElementById('baseRectangulo').value;
  let result = document.getElementById('areaRectangulo');

  let area = base * altura;

  result.innerHTML ="La area es de " + area + " cm²";
}