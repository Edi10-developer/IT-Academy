// Funcion para calcular el resultado del problema
function calcula() {
  let gradosCelsius = parseInt(document.getElementById("numero").value);
  let resultDiv = document.getElementById("resultDiv");
  let gradosFarenheit = trasformaGrados(gradosCelsius);

  resultDiv.innerHTML = gradosFarenheit;
}

// Funcion para el cambio de grados
function trasformaGrados(gradosCelsius) {
  gradosFarenheit = (gradosCelsius * 9 / 5) + 32;
  return gradosFarenheit;
}
