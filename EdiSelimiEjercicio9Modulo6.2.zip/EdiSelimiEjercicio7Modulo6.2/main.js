// Funcion para calcular el resultado del problema
function calcula() {
  let numero = parseInt(document.getElementById("numero").value);
  let fibonacciArray = [];

  let i;
  
  
for( i = 0; i < numero; i++){
  if( i == 0){
    fibonacciArray.push(i);
  }else if( i == 1){
    fibonacciArray.push(i);
  }else{
    fibonacciArray.push(fibonacciArray[i - 1] + fibonacciArray[i - 2]);
  }
}
 
  resultDiv.innerHTML = fibonacciArray;
}
