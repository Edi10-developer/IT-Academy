// Funcion para sacar medio arbol de Navidad
function calcula() {
  let resultDiv = document.getElementById("resultDiv");
  let numero = parseInt(document.getElementById("numero").value);
  let arbol = "";
  let asterisco = "*";

  let i;

  for (i = numero; i >= 1; i--) {
      for (j = 1; j < i; j++) {
        arbol += asterisco;
      }
      arbol += "<br/>";
    }

resultDiv.innerHTML = arbol;
}

