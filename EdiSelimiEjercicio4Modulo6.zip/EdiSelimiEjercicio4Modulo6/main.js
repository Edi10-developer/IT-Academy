function calcula() {
  let resultPar = document.getElementById("numeroPar");
  let resultInpar = document.getElementById("numeroInpar");
  let totNumeros = document.getElementById("numerosTotales");
  let numPar = [];
  let numInpar = [];
  let i;

  for (i = 100; i > 0; i--) {
    if (i % 2 == 0) {
      numPar.push(i);
    } else {
      numInpar.push(i);
    }
  }

  resultPar.innerHTML = "<h3>Los numeros par:</h3>" + numPar;
  resultInpar.innerHTML = "<h3>Los numeros inpar:</h3>" + numInpar;
}
