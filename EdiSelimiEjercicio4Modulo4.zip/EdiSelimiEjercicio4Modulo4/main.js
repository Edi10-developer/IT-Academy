function loteria() {
  let randomNum = Math.ceil(Math.random() * 10);
  let tentativos = 0;
  let trueNumb;
  do {
    trueNumb = parseInt(prompt("Qual crees se el numero ganador?"));
    tentativos++;
  } while (randomNum != trueNumb && tentativos < 5);

  if (tentativos < 5) {
    alert(
      "Enhorabuena! has adovinado el numero " +
        randomNum +
        " en " +
        tentativos +
        " tentativos "
    );
  } else {
    alert("Game Over! El numero de intentos maximo es 5!");
  }
}
