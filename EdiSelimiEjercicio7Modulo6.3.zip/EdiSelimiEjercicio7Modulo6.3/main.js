// Funcion principal
function start() {
  let result = document.getElementById('result');
  let personas = parseInt(document.getElementById('personas').value);
 
  let gFideuaPersona = 500 / 4;
  let gCalamaresPersona = 400 / 4;
  let gGambasPersona = 200 / 4;

  // Cantidad ingredientes por persona
  let totFideua = (gFideuaPersona * personas) / 1000;
  let totCalamares = (gCalamaresPersona * personas) / 1000;
  let totGambas = (gGambasPersona * personas) / 1000;

  let precioTotal =  calculaPrecioTotal(totFideua, totCalamares, totGambas);
  let precioTotalPersona = precioTotal / personas;

  result.style.display = "block";
  result.innerHTML = `<div>
  <p>La cantidad de Fideua necesaria sera de: ${totFideua} kg</p>
  <p>La cantidad de Calamares necesaria sera de: ${totCalamares} kg</p>
  <p>La cantidad de Gambas necesaria sera de: ${totGambas} kg</p><br/>
  <p>El precio Total sera de: ${precioTotal} Euros</p>
  <p>El precio por Persona sera de: ${precioTotalPersona} Euros</p>
  </div>`;
}

  // Precio total 
function calculaPrecioTotal(totFideua, totCalamares, totGambas){
  let precioKgFideua = parseInt(document.getElementById('precioFideua').value);
  let precioKgCalamares = parseInt(document.getElementById('precioCalamares').value);
  let precioKgGambas = parseInt(document.getElementById('precioGambas').value);

  let precioTotFideua =  totFideua * precioKgFideua;
  let precioTotCalamares =  totCalamares * precioKgCalamares;
  let precioTotGambas =  totGambas * precioKgGambas;

  let precioTotal = precioTotFideua + precioTotCalamares + precioTotGambas;
  
  return precioTotal;
}