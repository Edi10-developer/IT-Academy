// Funcion para calcular el resultado del problema
function calcula() {
  let numero = parseInt(document.getElementById("numero").value);
  let resultDiv = document.getElementById("resultDiv");
  let numeroInferior;
  let resultado = numero;
  let i;

  for (i = (numero - 1); i >= 1; i--) {
    numeroInferior = numero * i;
    resultado = resultado * i;
  } 
  resultDiv.innerHTML = resultado;
}
