const datos = document.getElementById('datos');

function muestraResultado() {
    let edadUsuario = parseInt(prompt("Cuanto años tienes?"));
    let tituloUniversitario = prompt("Tienes titulo universitario");
    let paro = prompt("Estas en el paro?");
   
    if(edadUsuario >= 18 && tituloUniversitario == "si" || paro == "si"){
        datos.innerHTML = "Tienes derecho a la beca";
    }
    else{
        datos.innerHTML = "No tienes derecho a la beca";
    }
   
 
    datos.style.opacity = 1;
}



