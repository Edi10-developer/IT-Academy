// Funcion principal
function calcula() {
  let numero = parseInt(document.getElementById("numero").value);
  let valor = calculaValor(numero);
  resultDiv.innerHTML = "<h5>" + valor + "</h5>";
}

function calculaValor(numero) {
  if (numero % 2 == 0) {
    valor = "Par";
  } else {
    valor = "Inpar";
  }
  return valor;
}
