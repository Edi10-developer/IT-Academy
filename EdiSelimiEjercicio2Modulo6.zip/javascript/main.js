// Funcion sumar numeros par y inpar in diferentes Arrays
function calcula() {
  let numeroNumeros = parseInt(document.getElementById("numero").value);
  let numerosPar = [];
  let numerosInpar = [];
  let num;
  for (i = 0; i < numeroNumeros; i++) {
    num = prompt("Introduce un numero:");
    if (num % 2 == 0) {
      numerosPar.push(num);
    } else {
      numerosInpar.push(num);
    }
    resultDiv.innerHTML =
      "<h6>Los numeros Par introducidos son :</h6><br/> " +
      numerosPar +
      "<br/></h6>" +
      "<h6>Los numeros Par introducidos son :</h6><br/> " +
      numerosInpar +
      "<br/></h6>";
  }
}
