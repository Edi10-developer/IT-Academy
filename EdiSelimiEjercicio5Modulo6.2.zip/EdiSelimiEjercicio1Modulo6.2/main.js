// Funcion para calcular el resultado del problema
function calcula() {
  let numero = parseInt(document.getElementById("numero").value);
  let mensaje = "";
  let primoAnterior;
  let primo = 0;

  for (primoAnterior = 2; primoAnterior < numero; primoAnterior++) {
    if (numero % primoAnterior == 0) {
      primo++;
    }
  }
  if (primo == 0) {
    mensaje += "Es un numero primo";
  } else {
    mensaje += "No es un numero primo";
  }
  alert(mensaje);
}
