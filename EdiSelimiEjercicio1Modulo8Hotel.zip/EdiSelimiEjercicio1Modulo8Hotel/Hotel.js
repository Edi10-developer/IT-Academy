class Hotel {
  // Attributes
  constructor(name, rooms, floors, surface) {
    this._name = name;
    this._rooms = rooms;
    this._floors = floors;
    this._surface = surface;
  }

  // SET Methods
  set name(name) {
    this._name = name;
  }
  set rooms(rooms) {
    this._rooms = rooms;
  }
  set floors(floors) {
    this._floors = floors;
  }
  set surface(surface) {
    this._surface = surface;
  }

  // GET Methods
  get name() {
    return this._name;
  }
  get rooms() {
    return this._rooms;
  }
  get floors() {
    return this._floors;
  }
  get surface() {
    return this._surface;
  }

  // Methods
  calcularManteniento() {
    let msg = "El hotel " + this._name  + " necessita " + Math.round(this.rooms / 20) + " camareros y el gasto total es de " +  + Math.round(this.rooms / 20)*1500 + " euro.";
    return msg;
  }
}

