let hotels = [];

let hotel1 = new Hotel('Hilton', 50, 34, 345);
let hotel2 = new Hotel('Riu', 80, 94, 9945);
hotels.push(hotel1);
hotels.push(hotel2);
//var frm = document.getElementById('myForm');

// Create New Hotel
function saveHotel() {
  let name = document.getElementById("name").value;
  let rooms = parseInt(document.getElementById("rooms").value);
  let floors = parseInt(document.getElementById("floors").value);
  let surface = parseInt(document.getElementById("surface").value);

  var found = false;

  for (hotel of hotels) {
    if (hotel.name == name) {
      found = true;
    }
  }
  if (!found) {
    var newHotel = new Hotel(
      name,
      rooms,
      floors,
      surface
    );
    hotels.push(newHotel);
  } else {
    alert("The hotel already exist");
  }
}


// Edit Hotel
function editHotel() {
  let nameEditHotel = document.getElementById("nameHoteltoEdit").value;

  let rooms = parseInt(document.getElementById("roomsToEdit").value);
  let floors = parseInt(document.getElementById("floorsToEdit").value);
  let surface = parseInt(document.getElementById("surfaceToEdit").value);
  let found = false;
  for (hotel of hotels) {
    if (nameEditHotel === hotel.name) {
      found = true;
    }
    if (found) {
      //let hotel = hotels.find(hotel => {return hotel.name === nameHotelToSee});
      hotel.rooms = rooms;
      hotel.floors = floors;
      hotel.surface = surface;
    } else {
      alert("Please feel the form with correct information");
    }
  }
}

// See Hotel Information
function seeHotel() {
  let nameHotelToSee = document.getElementById("nameHotelToSee").value;
  let found = false;
  for (hotel of hotels) {
    if (nameHotelToSee === hotel.name) {
      found = true;
    }
  }
  if (found == true) {
    let hotel = hotels.find(hotel => { return hotel.name === nameHotelToSee });
    document.getElementById(
      "info"
    ).innerHTML = `<h3>${hotel.name} Hotel</h3>
      <p>Had ${hotel.rooms} rooms, ${hotel.floors} floors and ${hotel.surface} mq of surface.</p>${hotel.calcularManteniento()}<p></p>
      `;
  } else {
    alert("Sorry. The hotel doesn't exist");
  }
}

// Delete Hotel And His Information
function deleteHotel() {
  let nameHotelToDelete = document.getElementById("nameHotelToDelete").value;
  for (hotel of hotels) {
    if (nameHotelToDelete === hotel.name) {
      found = true; 
    }
  }
    if(found){
      hotels.splice(hotels.indexOf(hotel), 1);
      alert("The hotel has been deleted");
    } else {
      alert("The hotel doesn't exist");
    }
  }



/******************************************
               CAROUSEL
*******************************************/
var imageArray = ['img/hotel1.jpg', 'img/hotel2.jpg', 'img/hotel3.jpg', 'img/hotel4.jpg', 'img/hotel5.jpg', ];
var imageIndex = 0;


function changeBgImage(){
  var imageUrl = "url('" + imageArray[imageIndex] + "')";
  document.body.style.backgroundImage = imageUrl;
  imageIndex++;
  if (imageIndex >= imageArray.length) {
      imageIndex = 0;
  }
}

setInterval(changeBgImage, 3000);