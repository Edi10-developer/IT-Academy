// Funcion principal
function start() {
  let dni = document.getElementById("dni").value.replace(/ /g, ""); //replace(/ /g, ''); quita los espacios de la string en manera global

  //Se calcula solo el numero quitando la letra
  let numeroDni = parseInt(dni.substring(0, 8));
  //Se calcula solo la letra quitando los numeros
  let letraDni = dni.substring(7);

  //Se calcula la letra correspondiente al número
  var letras = ['T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z', 'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E'];
  var letraCorrecta = letras[numeroDni % 23];

  //Se comprueba que el formato es válido
  if (numeroDni == /\d{8}[a-z A-Z]/) {
    numeroDni = parseInt(prompt("Introzuca un número válido de DNI"));
  } else if (dni === "") {
    alert("Los datos introducidos son incorrectos");
  }
  //Se comprueba si la letra introducida es igual a la calculada
  else if (letraDni.toUpperCase() != letraCorrecta) {
    alert(
      "Has introducido una letra incorrecta" +
        "\n" +
        "Tu letra debería ser: " +
        letraCorrecta
    );
  } else {
    alert("Enhorabuena hemos podido validar tu DNI");
  }
}
