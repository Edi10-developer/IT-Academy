// Datos introducidos del cliente
var nombre = (nombre = document.getElementById("name"));
var email = document.getElementById("email");
var telefono = document.getElementById("telefono");
var password = document.getElementById("password");
var passwordConfirm = document.getElementById("passwordConfirm");

// Funciones para Errores y Succesos mientras compilamos los inputs
nombre.addEventListener("change", validaNombre);
email.addEventListener("change", validaEmail);
telefono.addEventListener('change', validaTelefono);
password.addEventListener('change', validaPassword);
passwordConfirm.addEventListener('change', validaPasswordConfirm);

/*************************************
       FUNCCION PRINCIPAL - inicio
*************************************/

// Validacion Formulario
function validacion() {
  let valid = true;

  // Nombre
  if (nombre.value === "" || nombre.value.length < 5) {
    document.getElementById("name").style.border = "2px solid red";
    document.getElementById("errorName").innerHTML =
      "Escribir un nombre valido";
    nombre.focus();
    valid = false;
  }
  // Email
  if (email.value == "") {
    valid = false;
    email.style.border = "2px solid red";
    document.getElementById("errorEmail").innerHTML =
      "Escribir una email valida";
  }
  // Telefono
  let telefono = /^(\+34|0034|34)?[6|7|8|9][0-9]{8}$/;
  if (document.getElementById("telefono").value == "" || !telefono.test(document.getElementById("telefono").value)) {
    valid = false;
    document.getElementById("telefono").style.border = "2px solid red";
    document.getElementById("errorTelefono").innerHTML =
      "Escribir un telefono valid0";
  }
  // Password
  if (password.value == "" || password.value.length < 6) {
    valid = false;
    password.style.border = "2px solid red";
    document.getElementById("errorPassword").innerHTML =
      "Escribir una password valida";
  }
  // Confirma Password
  if (passwordConfirm.value != password.value) {
    valid = false;
    passwordConfirm.style.border = "2px solid red";
    document.getElementById("errorPasswordConfirm").innerHTML =
      "La password no corresponden";
  }
  return valid;
}
/**************  FUNCCION PRINCIPAL - fin  ***********************/
       

/****************************************
       FUNCCIONES SECUNDARIAS - inicio
*****************************************/

// Valida Nombre
function validaNombre(){
  if (nombre.value === "" || nombre.value.length < 5) {
    document.getElementById("name").style.border = "2px solid red";
    document.getElementById("errorName").innerHTML =
      "Escribir un nombre valido";
    nombre.focus();
    valid = false;
  }else {
    document.getElementById("name").style.border = "2px solid green";
  }
};

// Valida Email
function validaEmail(){
  valid = false;
  if ((email.value == "") || (email.value.length < 8)) {
    email.style.border = "2px solid red";
    document.getElementById("errorEmail").innerHTML =
      "Escribir una email valida";
  } else {
    valid = true;
    email.style.border = "2px solid green";
  }
}

// Valida Telefono
function validaTelefono(){
  let telefono = /^(\+34|0034|34)?[6|7|8|9][0-9]{8}$/;
  if (document.getElementById("telefono").value == "" || !telefono.test(document.getElementById("telefono").value)) {
    document.getElementById("telefono").style.border = "2px solid red";
    document.getElementById("errorTelefono").innerHTML =
      "Escribir un telefono valid0";
  } else {
    document.getElementById("telefono").style.border = "2px solid green";
  }
}

// Valida Password
function validaPassword(){
  if ((password.value === "") || (password.value.length < 6)) {
    password.style.border = "2px solid red";
    document.getElementById("errorPassword").innerHTML =
      "Escribir una password valida";
  } else {
    password.style.border = "2px solid green";
  }
}

// Valida Confirma Password
function validaPasswordConfirm(){
  if (passwordConfirm.value !== password.value) {
    passwordConfirm.style.border = "2px solid red";
    document.getElementById("errorPasswordConfirm").innerHTML =
      "La password no corresponden";
  } else {
    passwordConfirm.style.border = "2px solid green";
  }
}
/**************  FUNCIONES SECUNDARIAS - fin  ***********************/