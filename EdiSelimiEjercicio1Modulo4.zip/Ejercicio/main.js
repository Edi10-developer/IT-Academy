// Div contenedor del Array
const datos = document.querySelector("#datos");
// Array de palabras
let text = [];

function muestraResultado() {
  let number = parseInt(document.getElementById("number").value);

  for (let i = 0; i < number; i++) {
    let word = window.prompt("Escribe tu palabra: ");

    text.push(word + "<br/>");
    datos.innerHTML =
      `<h2>Las palabras que has escrito son las siguentes: </h2> 
       <br/>
       <h3>` +
      text +
      `</h3>`;
  }
}
