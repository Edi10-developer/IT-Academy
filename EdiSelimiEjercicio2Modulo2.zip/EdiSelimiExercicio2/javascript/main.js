const datos = document.getElementById('datos');

function muestraResultado() {
    let numero1 = parseInt(prompt("Dime un numero: ",));
    let numero2 = parseInt(prompt("Dime otro numero: ",));

    let sumaNumeros = numero1 + numero2;
    let restaNumeros = numero1 - numero2;
    let multiplicacionNumeros = numero1 * numero2;
    let divisionNumeros = numero1 / numero2;

    // Style
    datos.style.opacity = '1';

    // Por pantalla 
    datos.innerHTML = 
    `<ul>
         <li>La <strong>suma</strong> de ` + numero1 + ' y de ' + numero2 + ' es ' + sumaNumeros + `</li><br/>` +
        `<li>La <strong>resta</strong> de ` + numero1 + ' - de ' + numero2 + ' es ' + restaNumeros + `</li><br/>` +
        `<li>La <strong>multiplicacion</strong> de ` + numero1 + ' * ' + numero2 + ' es ' + multiplicacionNumeros + `</li><br/>` +
        `<li>La <strong>division</strong> de ` + numero1 + ' / ' + numero2 + ' es ' + divisionNumeros + `</li><br/>
    </ul>`;

  
}

