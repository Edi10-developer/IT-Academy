// Funccion principal
function generateSquare() {
  let number = parseInt(document.getElementById("number").value);
  let symbol = document.getElementById("symbol").value;
  let result = document.getElementById("resultado");
  let side = "";
  let square = "";
  let i, j;

  for (i = 1; i <= number; i++) {
    side = side + symbol;
    if (i == number) {
      side += "<br/>";
    }
  }
  for (j = 0; j < number; j++) {
    square += side;
  }
  result.style.display = "block";
  result.innerHTML = square;
}
