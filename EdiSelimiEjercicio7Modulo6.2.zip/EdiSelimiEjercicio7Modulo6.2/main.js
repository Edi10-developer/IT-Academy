// Funcion para calcular el resultado del problema
function calcula() {
  let year = parseInt(document.getElementById("numero").value);
  let resultDiv = document.getElementById("resultDiv");
  let mensaje = calsulaBisesto(year);

  resultDiv.innerHTML = mensaje;
}

// Funcion para el cambio de grados
function calsulaBisesto(year) {
  let mensaje = "";
  if ((year % 400 == 0) || (year % 4 == 0) && (year % 100 != 0)) {
    mensaje += "Es un año bisesto";
  } else {
    mensaje += "NO es un año bisesto";
  }
  return mensaje;
}
